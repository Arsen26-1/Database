#ifndef DIGITALCLOCK_H
#define DIGITALCLOCK_H

#include <QMainWindow>
#include <QTime>
#include <QDateTime>
#include <QDebug>
#include <QString>
#include <QLCDNumber>

QT_BEGIN_NAMESPACE
namespace Ui {
class DigitalClock;
}
QT_END_NAMESPACE

class DigitalClock : public QMainWindow
{
    Q_OBJECT

public:
    DigitalClock(QWidget *parent = nullptr);
    ~DigitalClock();

private:
    Ui::DigitalClock *ui;
    QTimer* DateTime;


private slots:
    void ShowTime();
};

#endif // DIGITALCLOCK_H
