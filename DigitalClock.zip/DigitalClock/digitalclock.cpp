#include "digitalclock.h"
#include "./ui_digitalclock.h"
#include "QtCore/qtimer.h"




DigitalClock::DigitalClock(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::DigitalClock)
{
    ui->setupUi(this);
    DateTime = new QTimer();
    DateTime->setInterval(1000);
    DateTime->start();


    connect(DateTime, SIGNAL(timeout()), this, SLOT(ShowTime()));

}

DigitalClock::~DigitalClock()
{
    delete ui;
}


void DigitalClock::ShowTime()
{
    QString DateAndTime = QDateTime::currentDateTime().toString("hh:mm:ss");
    ui->lcdNumber->display(DateAndTime);
}
